﻿using System;

class Program1
{
    static void Main(string[] args)
    {
        Console.Write("Введите количество участников: ");
        int n = int.Parse(Console.ReadLine());
        int[] a = new int[n];

        for (int i = 0; i < n; i++)
        {
            while (true)
            {
                Console.Write($"Введите возраст участника {i + 1} (0-120): ");
                int age = int.Parse(Console.ReadLine());

                if (age >= 0 && age <= 120)
                {
                    a[i] = age;
                    break;
                }
                else
                {
                    Console.WriteLine("Ошибка: введенное значение должно быть от 0 до 120. Пожалуйста, попробуйте еще раз.");
                }
            }
        }
        double m = 0;
        for (int i = 0; i < n; i++)
        {
            m += a[i];
        }
        m /= n;
        int minAge = a[0];
        int maxAge = a[0];

        for (int i = 1; i < n; i++)
        {
            if (a[i] < minAge)
            {
                minAge = a[i];
            }
            if (a[i] > maxAge)
            {
                maxAge = a[i];
            }
        }
        Console.WriteLine("Средний возраст: " + m);
        Console.WriteLine("Минимальный возраст: " + minAge);
        Console.WriteLine("Максимальный возраст: " + maxAge);
    }
}