﻿using System;
using System.Collections.Generic;

namespace Zadacha1
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> numbers = new List<int>();
            string[] input = Console.ReadLine().Split(' ');
            foreach (string number in input)
            {
                int num;
                if (int.TryParse(number, out num))
                {
                    numbers.Add(num);
                }
            }

            HashSet<int> distinctNumbers = new HashSet<int>(numbers);
            int count = distinctNumbers.Count;

            Console.WriteLine(count);
        }
    }
}