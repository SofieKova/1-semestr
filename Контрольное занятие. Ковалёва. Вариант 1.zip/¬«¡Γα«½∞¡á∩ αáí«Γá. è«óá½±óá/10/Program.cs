﻿using System;
namespace Zadacha10
{
    class Program
    {
        static void Main()
        {
            string[] input = Console.ReadLine().Split();
            int n = int.Parse(input[0]); 
            int k = int.Parse(input[1]);

            bool[] strikes = new bool[n + 1];

            for (int i = 0; i < k; i++)
            {
                string[] line = Console.ReadLine().Split();
                int a = int.Parse(line[0]); 
                int b = int.Parse(line[1]); 

                for (int day = a; day <= n; day += b)
                {
                    int dayOfWeek = (day - 1) % 7; 
                    if (dayOfWeek != 5 && dayOfWeek != 6)
                    {
                        strikes[day] = true; 
                    }
                }
            }

            int totalStrikes = 0;
            for (int day = 1; day <= n; day++)
            {
                if (strikes[day])
                {
                    totalStrikes++; 
                }
            }

            Console.WriteLine(totalStrikes);
        }
    }
}
