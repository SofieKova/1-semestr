﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Zadacha11
{

    class Program
    {
        static void Main()
        {
            string filePath = "1ри!.1х0";

            string textToWrite = "one two one two three";

            File.WriteAllText(filePath, textToWrite);

            string textToAppend = "She sells sea shells on the sea shore. The shells that she sells are sea shells I'm sure. So if she sells sca shells on the sca shore, I'm sure that the shells are sea shore shells.";

            File.AppendAllText(filePath, textToAppend);

            string content = File.ReadAllText(filePath);
            Console.WriteLine("\nСодержимое файла:");
            Console.WriteLine(content);

            var words = content.Split(new[] { ' ', '\n', '\r', '.', ',', '!', '?' }, StringSplitOptions.RemoveEmptyEntries);

            Dictionary<string, int> wordCount = new Dictionary<string, int>();
            List<int> results = new List<int>();

            foreach (var word in words)
            {
                string normalizedWord = word.ToLower();

                if (wordCount.ContainsKey(normalizedWord))
                {
                    results.Add(wordCount[normalizedWord]);
                    wordCount[normalizedWord]++;
                }
                else
                {
                    results.Add(0);
                    wordCount[normalizedWord] = 1;
                }
            }

            Console.WriteLine("\nРезультаты подсчета слов:");
            Console.WriteLine(string.Join(", ", results));
        }
    }
}
