﻿using System;
using System.Collections.Generic;
using System.IO;

class Program
{
    static void Main()
    {
        Dictionary<string, string> synonyms = new Dictionary<string, string>();

        string filePath = "TextFile1.txt";

        using (StreamReader reader = new StreamReader(filePath))
        {
            string line;
            while ((line = reader.ReadLine()) != null && !string.IsNullOrWhiteSpace(line))
            {
                string[] words = line.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                if (words.Length == 2)
                {
                    synonyms[words[0]] = words[1];
                    synonyms[words[1]] = words[0];
                }
            }

            while ((line = reader.ReadLine()) != null)
            {
                line = line.Trim(); 
                if (synonyms.ContainsKey(line))
                {
                    Console.WriteLine(synonyms[line]); 
                }
                else
                {
                    Console.WriteLine($"Синоним для '{line}' не найден."); 
                }
            }
        }
    }
}
