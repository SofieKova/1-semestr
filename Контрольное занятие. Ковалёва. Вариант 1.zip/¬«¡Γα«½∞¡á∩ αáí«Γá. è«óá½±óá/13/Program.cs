﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main()
    {
        Dictionary<string, int> votes = new Dictionary<string, int>();

        string line;
        while ((line = Console.ReadLine()) != null && !string.IsNullOrWhiteSpace(line))
        {
            string[] parts = line.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length == 2)
            {
                string candidate = parts[0]; 
                int voteCount = int.Parse(parts[1]); 

                if (votes.ContainsKey(candidate))
                {
                    votes[candidate] += voteCount;
                }
                else
                {
                    votes[candidate] = voteCount;
                }
            }
        }

        var sortedCandidates = votes.Keys.OrderBy(k => k);

        foreach (var candidate in sortedCandidates)
        {
            Console.WriteLine($"{candidate} {votes[candidate]}");
        }
    }
}
