﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main()
    {
        string input = Console.ReadLine(); 
        string[] words = input.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries); 

        Dictionary<string, int> wordCount = new Dictionary<string, int>();

        foreach (string word in words)
        {
            if (wordCount.ContainsKey(word))
            {
                wordCount[word]++;
            }
            else
            {
                wordCount[word] = 1;
            }
        }

        string mostFrequentWord = null;
        int maxCount = 0;

        foreach (var kvp in wordCount)
        {
            if (kvp.Value > maxCount ||
               (kvp.Value == maxCount && (mostFrequentWord == null || String.Compare(kvp.Key, mostFrequentWord) < 0)))
            {
                mostFrequentWord = kvp.Key;
                maxCount = kvp.Value;
            }
        }

        Console.WriteLine(mostFrequentWord);
    }
}
