﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        int N = int.Parse(Console.ReadLine());
        Dictionary<string, HashSet<string>> filePermissions = new Dictionary<string, HashSet<string>>();

        for (int i = 0; i < N; i++)
        {
            string line = Console.ReadLine();
            string[] parts = line.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            string fileName = parts[0];
            HashSet<string> permissions = new HashSet<string>(parts[1..]);

            filePermissions[fileName] = permissions; 
        }

        int M = int.Parse(Console.ReadLine());

        for (int i = 0; i < M; i++)
        {
            string line = Console.ReadLine();
            string[] requestParts = line.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            string operation = requestParts[0];
            string requestedFile = requestParts[1];

            if (filePermissions.TryGetValue(requestedFile, out HashSet<string> permissions) && permissions.Contains(operation))
            {
                Console.WriteLine("OK");
            }
            else
            {
                Console.WriteLine("Access denied"); 
            }
        }
    }
}
