﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Zadacha2
{
    class Program
    {
        static void Main()
        {
            string[] firstListInput = Console.ReadLine().Split(' ');
            HashSet<int> firstList = new HashSet<int>();

            foreach (var num in firstListInput)
            {
                firstList.Add(int.Parse(num));
            }

            string[] secondListInput = Console.ReadLine().Split(' ');
            HashSet<int> secondList = new HashSet<int>();

            foreach (var num in secondListInput)
            {
                secondList.Add(int.Parse(num));
            }

            firstList.IntersectWith(secondList);

            Console.WriteLine(firstList.Count);
        }
    }
}


