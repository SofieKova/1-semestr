﻿using System;
using System.Collections.Generic;

namespace Zadacha3
{

    class Program
    {
        static void Main()
        {
            string[] firstListInput = Console.ReadLine().Split(' ');
            HashSet<int> firstList = new HashSet<int>();

            foreach (var num in firstListInput)
            {
                firstList.Add(int.Parse(num));
            }

            string[] secondListInput = Console.ReadLine().Split(' ');
            HashSet<int> secondList = new HashSet<int>();

            foreach (var num in secondListInput)
            {
                secondList.Add(int.Parse(num));
            }

            firstList.IntersectWith(secondList);

            List<int> result = new List<int>(firstList);
            result.Sort();

            Console.WriteLine(string.Join(" ", result));
        }
    }
}
