﻿using System;
using System.Collections.Generic;

namespace Zadacha4
{

    class Program
    {
        static void Main()
        {
            string input = Console.ReadLine();
            string[] numbers = input.Split(' ');

            HashSet<string> seenNumbers = new HashSet<string>();

            foreach (var number in numbers)
            {
                if (seenNumbers.Contains(number))
                {
                    Console.WriteLine("YES");
                }
                else
                {
                    Console.WriteLine("NO");
                    seenNumbers.Add(number);
                }
            }
        }
    }
}
