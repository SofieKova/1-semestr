﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Zadacha5
{

    class Program
    {
        static void Main()
        {
            string[] firstLine = Console.ReadLine().Split(' ');
            int N = int.Parse(firstLine[0]);
            int M = int.Parse(firstLine[1]);

            HashSet<int> anyaCubes = new HashSet<int>();
            HashSet<int> boryaCubes = new HashSet<int>();

            for (int i = 0; i < N; i++)
            {
                anyaCubes.Add(int.Parse(Console.ReadLine()));
            }

            for (int i = 0; i < M; i++)
            {
                boryaCubes.Add(int.Parse(Console.ReadLine()));
            }

            var commonColors = anyaCubes.Intersect(boryaCubes).ToList();
            commonColors.Sort();

            var uniqueAnyaColors = anyaCubes.Except(boryaCubes).ToList();
            uniqueAnyaColors.Sort();

            var uniqueBoryaColors = boryaCubes.Except(anyaCubes).ToList();
            uniqueBoryaColors.Sort();

            Console.WriteLine(commonColors.Count);
            Console.WriteLine(string.Join(" ", commonColors));

            Console.WriteLine(uniqueAnyaColors.Count);
            Console.WriteLine(string.Join(" ", uniqueAnyaColors));

            Console.WriteLine(uniqueBoryaColors.Count);
            Console.WriteLine(string.Join(" ", uniqueBoryaColors));
        }
    }
}
