﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Zadacha6
{

    class Program
    {
        static void Main()
        {
            string filePath = "input.txt";

            HashSet<string> uniqueWords = new HashSet<string>();

            try
            {
                string text = File.ReadAllText(filePath);

                string[] words = text.Split(new char[] { ' ', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);

                foreach (string word in words)
                {
                    uniqueWords.Add(word);
                }

                Console.WriteLine($"Количество различных слов: {uniqueWords.Count}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при чтении файла: {ex.Message}");
            }
        }
    }
}
