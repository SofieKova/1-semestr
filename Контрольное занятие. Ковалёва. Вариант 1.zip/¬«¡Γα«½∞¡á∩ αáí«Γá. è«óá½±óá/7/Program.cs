﻿using System;
using System.Collections.Generic;

namespace Zadacha7
{

    class Program
    {
        static void Main()
        {
            int n = int.Parse(Console.ReadLine());

            HashSet<int> possibleNumbers = new HashSet<int>();
            for (int i = 1; i <= n; i++)
            {
                possibleNumbers.Add(i);
            }

            while (true)
            {
                string line = Console.ReadLine();
                if (line == "HELP")
                    break;

                string[] parts = line.Split(' ');
                HashSet<int> guessedNumbers = new HashSet<int>();
                foreach (var part in parts)
                {
                    guessedNumbers.Add(int.Parse(part));
                }

                string answer = Console.ReadLine();
                if (answer == "YES")
                {
                    possibleNumbers.IntersectWith(guessedNumbers);
                }
                else
                {
                    foreach (var number in guessedNumbers)
                    {
                        possibleNumbers.Remove(number);
                    }
                }
            }

            List<int> result = new List<int>(possibleNumbers);
            result.Sort();
            Console.WriteLine(string.Join(" ", result));
        }
    }
}
