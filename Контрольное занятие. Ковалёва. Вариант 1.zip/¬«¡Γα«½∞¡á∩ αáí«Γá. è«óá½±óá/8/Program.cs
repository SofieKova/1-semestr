﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Zadacha8
{

    class Program
    {
        static void Main()
        {
            int n = int.Parse(Console.ReadLine());
            HashSet<int> possibleNumbers = new HashSet<int>(Enumerable.Range(1, n));
            string input;

            while ((input = Console.ReadLine()) != "HELP")
            {
                var questionNumbers = input.Split(' ').Select(int.Parse).ToList();
                int count = questionNumbers.Count;

                if (count == possibleNumbers.Count / 2)
                {
                    Console.WriteLine("NO");
                    continue;
                }

                var askedSet = new HashSet<int>(questionNumbers);
                var intersection = possibleNumbers.Intersect(askedSet).ToList();

                if (intersection.Count > 0 && intersection.Count < count)
                {
                    Console.WriteLine("YES");
                }
                else
                {
                    Console.WriteLine("NO");
                }

                if (intersection.Count > 0)
                {
                    possibleNumbers.ExceptWith(askedSet);
                }
            }

            Console.WriteLine(string.Join(" ", possibleNumbers.OrderBy(x => x)));
        }
    }
}