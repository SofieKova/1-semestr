﻿using System;
using System.Collections.Generic;

namespace Zadacha9
{

    class Program
    {
        static void Main()
        {
            int n = int.Parse(Console.ReadLine());
            HashSet<string> allLanguages = new HashSet<string>();
            HashSet<string> commonLanguages = null;

            for (int i = 0; i < n; i++)
            {
                int m = int.Parse(Console.ReadLine());
                HashSet<string> currentLanguages = new HashSet<string>();

                for (int j = 0; j < m; j++)
                {
                    string language = Console.ReadLine().Trim();
                    currentLanguages.Add(language);
                    allLanguages.Add(language);
                }

                if (commonLanguages == null)
                {
                    commonLanguages = new HashSet<string>(currentLanguages);
                }
                else
                {
                    commonLanguages.IntersectWith(currentLanguages);
                }
            }

            Console.WriteLine(commonLanguages.Count);
            foreach (var lang in commonLanguages)
            {
                Console.WriteLine(lang);
            }

            Console.WriteLine(allLanguages.Count);
            foreach (var lang in allLanguages)
            {
                Console.WriteLine(lang);
            }
        }
    }
}

