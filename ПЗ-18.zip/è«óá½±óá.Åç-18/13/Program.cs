﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите значение A: ");
        double A = Convert.ToDouble(Console.ReadLine());

        double maxX = 70; 
        int height = 20; 
        int width = 70;

        for (int i = 0; i < height; i++)
        {
            double y = A * Math.Exp(-(i * maxX / height) / 7);

            int xPosition = (int)(i * width / height);
            int yPosition = (int)(y / (A) * height); 

            
            for (int j = 0; j < width; j++)
            {
                if (j == xPosition)
                {
                    Console.Write('*'); 
                }
                else
                {
                    Console.Write(' '); 
                }
            }
            Console.WriteLine(); 
        }

        Console.SetCursorPosition(0, height);
        for (int j = 0; j < width; j++)
        {
            Console.Write('-'); 
        }
        Console.WriteLine();
    }
}

