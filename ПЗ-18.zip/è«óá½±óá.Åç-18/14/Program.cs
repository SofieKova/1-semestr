﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите значение A (A >= 0): ");
        double A = Convert.ToDouble(Console.ReadLine());

        Console.Write("Введите значение ν (ню): ");
        double nu = Convert.ToDouble(Console.ReadLine());

        Console.Write("Введите значение a (a ∈ [0, π]): ");
        double a = Convert.ToDouble(Console.ReadLine());

        Console.Write("Введите количество итераций: ");
        int iterations = Convert.ToInt32(Console.ReadLine());

        double pi = Math.PI; 
        double maxY = A;

        double rectangleArea = (pi - 0) * maxY; 

        int pointsUnderCurve = 0;
        Random random = new Random();

        for (int i = 0; i < iterations; i++)
        {
            double t = random.NextDouble() * pi; 
            double y = random.NextDouble() * maxY; 

            if (y <= A * Math.Sin(nu * t + a))
            {
                pointsUnderCurve++;
            }
        }

        double areaUnderCurve = (double)pointsUnderCurve / iterations * rectangleArea;

        Console.WriteLine($"Приблизительная площадь фигуры, ограниченной графиком: {areaUnderCurve}");
    }
}
