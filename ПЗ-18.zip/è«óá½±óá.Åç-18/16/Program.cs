﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите начальную точку интервала (a): ");
        double a = Convert.ToDouble(Console.ReadLine());

        Console.Write("Введите конечную точку интервала (b): ");
        double b = Convert.ToDouble(Console.ReadLine());

        Console.Write("Введите шаг изменения аргумента: ");
        double step = Convert.ToDouble(Console.ReadLine());

        if (a >= b)
        {
            Console.WriteLine("Начальная точка интервала должна быть меньше конечной точки.");
            return;
        }
        if (step <= 0)
        {
            Console.WriteLine("Шаг должен быть положительным числом.");
            return;
        }

        double area = 0.0;
        for (double x = a; x < b; x += step)
        {
            double y = 3 * x * x - 2 * x + 5;

            area += y * step;
        }

        if (b - a > 0)
        {
            double lastX = b;
            double lastY = 3 * lastX * lastX - 2 * lastX + 5;
            area += lastY * (b - (a + Math.Floor((b - a) / step) * step));
        }

        Console.WriteLine($"Приблизительная площадь под кривой на интервале [{a}, {b}] равна: {area}");
    }
}
