﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите целое число для меньшей диагонали ромба: ");
        int d1 = Convert.ToInt32(Console.ReadLine());

        int d2 = 2 * d1; 
        int height = d1 / 2; 

        if (d1 % 2 != 0)
        {
            Console.WriteLine("Введите четное число для меньшей диагонали.");
            return;
        }

        for (int i = 0; i < height; i++)
        {
            Console.Write(new string(' ', height - i));

            Console.WriteLine(new string('*', d1 + 2 * i));
        }

        for (int i = height - 1; i >= 0; i--)
        { 
            Console.Write(new string(' ', height - i));

            Console.WriteLine(new string('*', d1 + 2 * i));
        }
    }
}

