﻿using System;

namespace HappyTickets
{
    class Program
    {
        static int CalculateHappyTickets(int digits)
        {
            int happyTickets = 0;

            for (int i = 0; i < Math.Pow(10, digits); i++)
            {
                int firstHalf = i / 10;

                int secondHalf = i % 10;

                if (firstHalf == secondHalf)
                {
                    happyTickets++;
                }
            }

            return happyTickets;
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Введите количество цифр в номере билета:");
            int digits = int.Parse(Console.ReadLine());

            int happyTickets = CalculateHappyTickets(digits);

            Console.WriteLine($"Количество \"счастливых\" билетов: {happyTickets}");
        }
    }
}