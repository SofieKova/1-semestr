﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите число типа unsigned long: ");
        if (!ulong.TryParse(Console.ReadLine(), out ulong number))
        {
            Console.WriteLine("Некорректный ввод. Пожалуйста, введите допустимое число.");
            return;
        }

        int countOfOnes = CountOnesInBinary(number);

        if (countOfOnes % 2 == 0)
        {
            Console.WriteLine($"Количество единиц в двоичном представлении числа {number} равно {countOfOnes} и является четным.");
        }
        else
        {
            Console.WriteLine($"Количество единиц в двоичном представлении числа {number} равно {countOfOnes} и является нечетным.");
        }
    }

    static int CountOnesInBinary(ulong number)
    {
        int count = 0;

        while (number > 0)
        {
            count += (int)(number & 1);
            number >>= 1;
        }

        return count;
    }
}
