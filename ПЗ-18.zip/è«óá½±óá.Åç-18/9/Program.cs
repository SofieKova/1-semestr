﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите число в восьмеричной системе счисления: ");
        string octalInput = Console.ReadLine();

        try
        {
            ulong decimalValue = Convert.ToUInt64(octalInput, 8);

            Console.WriteLine($"Десятичное представление: {decimalValue}");
        }
        catch (FormatException)
        {
            Console.WriteLine("Некорректный ввод. Пожалуйста, введите допустимое восьмеричное число.");
        }
        catch (OverflowException)
        {
            Console.WriteLine("Ошибка: Введенное число слишком велико для типа ulong.");
        }
    }
}
