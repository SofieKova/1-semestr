
namespace Kovaleva22
{
    public class Class1
    {
    }

}
