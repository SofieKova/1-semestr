namespace Kovaleva22
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void label1_Click(object sender, EventArgs e)
        {

        }

        public void label3_Click(object sender, EventArgs e)
        {

        }

        public void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            this.dateTimePicker1.Location = new System.Drawing.Point(12, 200);
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
        }

        public void button1_Click(object sender, EventArgs e)
        {

        }

        public void button1_Click_1(object sender, EventArgs e)
        {


        }

        public void Form1_Load(object sender, EventArgs e)
        {


        }

        public void textBox1_TextChanged(object sender, EventArgs e)
        {
            this.textBox1.Location = new System.Drawing.Point(12, 12);
            this.textBox1.Size = new System.Drawing.Size(200, 20);
            this.textBox1.Name = "������";

            this.textBox3.Location = new System.Drawing.Point(12, 12);
            this.textBox3.Size = new System.Drawing.Size(200, 20);
            this.textBox3.Name = "��������";
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            this.textBox2.Location = new System.Drawing.Point(12, 12);
            this.textBox2.Size = new System.Drawing.Size(200, 20);
            this.textBox2.Name = "����";
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
