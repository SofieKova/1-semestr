﻿using System;

namespace DateTimeFormat
{
    class Program
    {
        static void Main(string[] args)
        {
            DateTime now = DateTime.Now;

            Console.WriteLine("Time: " + now.ToString("hh:mm:ss")); 

            
            Console.WriteLine("Data: " + now.ToString("dd.MM.yyyy")); 
        }
    }
}
